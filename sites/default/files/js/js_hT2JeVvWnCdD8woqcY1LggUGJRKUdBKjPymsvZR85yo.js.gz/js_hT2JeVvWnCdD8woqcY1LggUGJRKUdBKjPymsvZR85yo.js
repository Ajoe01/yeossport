/* @license GNU-GPL-2.0-or-later https://www.drupal.org/licensing/faq */
(function($,drupalSettings){setTimeout(()=>{$.ajax({type:'POST',cache:false,url:drupalSettings.statistics.url,data:drupalSettings.statistics.data});});})(jQuery,drupalSettings);;
